package com.plugin.internet.core;

import com.plugin.common.utils.UtilsConfig;

public class InternetConfig {

	public static final boolean DEBUG = true & UtilsConfig.UTILS_DEBUG;

	public static final int SIG_PARAM_MAX_LENGTH = 5000;

}
