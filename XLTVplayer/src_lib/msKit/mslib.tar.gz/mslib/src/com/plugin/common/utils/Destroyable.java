/**
 * Destroyable.java
 */
package com.plugin.common.utils;

/**
 * @author Guoqing Sun Oct 13, 20122:09:52 PM
 */
public interface Destroyable {

    void onDestroy();
    
}
