package com.plugin.common.cache.image;

public class BitmapCacheOption {

    public boolean needThumbnail;
    
    public boolean openThumbnailSizeCheck;
    
    public int thumbnailSize = 200;
    
}
