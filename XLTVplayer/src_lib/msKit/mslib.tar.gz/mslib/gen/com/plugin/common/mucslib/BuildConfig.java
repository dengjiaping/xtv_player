/** Automatically generated file. DO NOT MODIFY */
package com.plugin.common.mucslib;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}